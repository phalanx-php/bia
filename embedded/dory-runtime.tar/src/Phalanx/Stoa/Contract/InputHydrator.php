<?php

declare(strict_types=1);

namespace Phalanx\Stoa\Contract;

use Phalanx\Scope\Scope;
use Phalanx\Stoa\RequestContext;
use Phalanx\Stoa\ValidationException;
use Phalanx\Task\Executable;
use Phalanx\Task\Scopeable;
use ReflectionClass;
use ReflectionNamedType;
use ReflectionParameter;

class InputHydrator
{
    /** @var array<class-string, ?InputMeta> */
    private static array $metaCache = [];

    /** @var array<class-string, int> */
    private static array $paramCountCache = [];

    /** @phpstan-var array<string, ReflectionClass<object>> */
    private static array $reflectionCache = [];

    /** @var list<class-string> */
    private static array $scopeTypes = [
        Scope::class,
    ];

    /**
     * Count the parameters declared on the handler's __invoke method.
     *
     * Used to short-circuit hydration for handlers that take no parameters
     * at all (not even a scope), returning an empty args array.
     *
     * @param class-string<Scopeable|Executable>|Scopeable|Executable $handler
     */
    public static function paramCount(string|Scopeable|Executable $handler): int
    {
        $key = is_string($handler) ? $handler : $handler::class;

        if (array_key_exists($key, self::$paramCountCache)) {
            return self::$paramCountCache[$key];
        }

        $ref = self::$reflectionCache[$key] ??= new ReflectionClass($key); // @phpstan-ignore assign.propertyType
        $count = $ref->getMethod('__invoke')->getNumberOfParameters();
        self::$paramCountCache[$key] = $count;

        return $count;
    }

    /**
     * Reflect on the handler's __invoke and find the typed input parameter.
     *
     * @param class-string|Scopeable|Executable $handler
     */
    public static function meta(string|Scopeable|Executable $handler): ?InputMeta
    {
        $key = is_string($handler) ? $handler : $handler::class;

        if (array_key_exists($key, self::$metaCache)) {
            return self::$metaCache[$key];
        }

        $cls = self::$reflectionCache[$key] ??= new ReflectionClass($key);
        $ref = $cls->getMethod('__invoke');
        $meta = null;

        foreach ($ref->getParameters() as $param) {
            $type = $param->getType();

            if (!$type instanceof ReflectionNamedType) {
                continue;
            }

            $typeName = $type->getName();

            if (self::isScopeType($typeName)) {
                continue;
            }

            if (class_exists($typeName)) {
                $meta = new InputMeta(
                    inputClass: $typeName,
                    paramName: $param->getName(),
                );
                break;
            }
        }

        self::$metaCache[$key] = $meta;

        return $meta;
    }

    /**
     * Resolve handler arguments: scope + any hydrated inputs.
     *
     * Handlers with zero parameters receive an empty args array. Handlers
     * with only a scope parameter receive [$scope]. Handlers with a scope
     * plus a typed DTO parameter receive [$scope, $dto].
     *
     * @param class-string<Scopeable|Executable>|Scopeable|Executable $handler
     * @return list<mixed>
     */
    public static function resolve(
        string|Scopeable|Executable $handler,
        RequestContext $ctx,
    ): array {
        if (self::paramCount($handler) === 0) {
            return [];
        }

        $meta = self::meta($handler);

        if ($meta === null) {
            return [$ctx];
        }

        $source = InputSource::fromMethod($ctx->method());
        $data = match ($source) {
            InputSource::Body => $ctx->body->all(),
            InputSource::Query => $ctx->query->all(),
        };

        /** @var class-string $class */
        $class = $meta->inputClass;
        [$args, $errors] = self::resolveArgs($class, $data);

        if ($errors !== []) {
            throw new ValidationException($errors);
        }

        $ref = new ReflectionClass($class);
        $dto = $ref->newLazyGhost(static function (object $instance) use ($ref, $args): void {
            foreach ($args as $name => $value) {
                $ref->getProperty($name)->setValue($instance, $value);
            }
        });

        if (is_subclass_of($class, Validatable::class)) {
            $ref->initializeLazyObject($dto);
            assert($dto instanceof Validatable);
            $validationErrors = $dto->validate();
            if ($validationErrors !== []) {
                throw new ValidationException($validationErrors);
            }
        }

        return [$ctx, $dto];
    }

    /**
     * Resolve constructor arguments from raw data.
     *
     * @param class-string $class
     * @param array<string, mixed> $data
     * @return array{0: array<string, mixed>, 1: array<string, list<string>>}
     */
    protected static function resolveArgs(string $class, array $data): array
    {
        $ref = self::$reflectionCache[$class] ??= new ReflectionClass($class);
        $constructor = $ref->getConstructor();

        if ($constructor === null) {
            return [[], []];
        }

        $args = [];
        $errors = [];

        foreach ($constructor->getParameters() as $param) {
            $name = $param->getName();
            $exists = array_key_exists($name, $data);

            if (!$exists && !$param->isOptional() && !self::isNullableParam($param)) {
                $errors[$name][] = 'This field is required';
                continue;
            }

            if (!$exists) {
                if ($param->isDefaultValueAvailable()) {
                    $args[$name] = $param->getDefaultValue();
                } elseif (self::isNullableParam($param)) {
                    $args[$name] = null;
                }
                continue;
            }

            $value = $data[$name];

            if ($value === null && self::isNullableParam($param)) {
                $args[$name] = null;
                continue;
            }

            $type = $param->getType();
            if (!$type instanceof ReflectionNamedType) {
                $args[$name] = $value;
                continue;
            }

            $coerced = self::coerce($value, $type, $name, $errors);
            if (!array_key_exists($name, $errors)) {
                $args[$name] = $coerced;
            }
        }

        return [$args, $errors];
    }

    /**
     * @param array<string, list<string>> $errors
     */
    protected static function coerce(
        mixed $value,
        ReflectionNamedType $type,
        string $field,
        array &$errors,
    ): mixed {
        $typeName = $type->getName();

        if (enum_exists($typeName)) {
            if (!is_string($value) && !is_int($value)) {
                $errors[$field][] = "Invalid value for {$field}";

                return null;
            }

            try {
                /** @var class-string<\BackedEnum> $typeName */
                return $typeName::from($value);
            } catch (\ValueError) {
                $ref = new ReflectionClass($typeName);
                $cases = $ref->getMethod('cases')->invoke(null);
                $allowed = implode(', ', array_map(
                    static fn($c) => $c->value ?? $c->name,
                    $cases,
                ));
                $errors[$field][] = "Invalid value '{$value}'. Expected: {$allowed}";

                return null;
            }
        }

        return match ($typeName) {
            'string' => (string) $value,
            'int' => is_numeric($value) ? (int) $value : (static function () use ($field, &$errors) {
                $errors[$field][] = 'Must be an integer';

                return null;
            })(),
            'float' => is_numeric($value) ? (float) $value : (static function () use ($field, &$errors) {
                $errors[$field][] = 'Must be a number';

                return null;
            })(),
            'bool' => filter_var($value, FILTER_VALIDATE_BOOLEAN, FILTER_NULL_ON_FAILURE) ?? (static function () use ($field, &$errors) {
                $errors[$field][] = 'Must be a boolean';

                return null;
            })(),
            'array' => is_array($value) ? $value : (static function () use ($field, &$errors) {
                $errors[$field][] = 'Must be an array';

                return null;
            })(),
            default => $value,
        };
    }

    private static function isScopeType(string $typeName): bool
    {
        foreach (self::$scopeTypes as $scopeType) {
            if ($typeName === $scopeType || is_subclass_of($typeName, $scopeType)) {
                return true;
            }
        }

        return false;
    }

    private static function isNullableParam(ReflectionParameter $param): bool
    {
        $type = $param->getType();

        if ($type === null) {
            return true;
        }

        return $type->allowsNull();
    }
}
