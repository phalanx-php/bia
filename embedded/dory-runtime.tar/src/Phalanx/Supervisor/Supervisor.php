<?php

declare(strict_types=1);

namespace Phalanx\Supervisor;

use Phalanx\Cancellation\CancellationToken;
use Phalanx\Diagnostics\DiagnosticCode;
use Phalanx\Pool\ObjectPool;
use Phalanx\Scope\BorrowedScopeFrame;
use Phalanx\Scope\Cancellable;
use Phalanx\Scope\Scope;
use Phalanx\Scope\ScopeIdentity;
use Phalanx\Task\Executable;
use Phalanx\Task\Scopeable;
use Phalanx\Task\Task;
use Phalanx\Trace\Trace;
use Phalanx\Trace\TraceType;
use ReflectionFunction;
use SplStack;
use Throwable;

/**
 * Coordinator for every dispatchable task in a Phalanx application.
 *
 * Every primitive that runs user-visible work — execute, concurrent,
 * race, any, map, series, waterfall, settle, defer, singleflight,
 * inWorker, timeout, retry — routes through Supervisor::start(). One
 * execution path, one lease ledger, one cancellation source, one trace
 * correlation per running thing.
 *
 * This is the load-bearing 0.2 invariant. Any primitive that bypasses
 * this path silently drops middleware, lease tracking, wait reasons,
 * worker placement inference, and the live task-tree diagnostic surface.
 *
 * Sibling-isolation invariant:
 *   When start() is called with DispatchMode::Concurrent, the caller is
 *   responsible for handing the child its own scope object with its own
 *   scoped-instance map, its own dispose stack, and its own cancellation
 *   token linked to the parent's token as a source. The supervisor does
 *   NOT amplify pool depth — pools live in the singleton container,
 *   which is shared across siblings. See the "Pool & Scope Discipline"
 *   section of the package README for the full invariants.
 */
final class Supervisor
{
    /** @var ObjectPool<TaskRun> */
    private ObjectPool $taskRunPool;

    /** @var ObjectPool<BorrowedScopeFrame> */
    private ObjectPool $scopeFramePool;

    /** @var SplStack<CancellationToken> */
    private SplStack $tokenPool;

    private int $tokenPoolCapacity;

    private int $tokenPoolHits = 0;

    private int $tokenPoolMisses = 0;

    public function __construct(
        private(set) LedgerStorage $ledger,
        private(set) Trace $trace,
        int $taskRunPoolCapacity = 256,
        int $scopeFramePoolCapacity = 256,
        int $tokenPoolCapacity = 512,
    ) {
        $this->taskRunPool = new ObjectPool(TaskRun::class, $taskRunPoolCapacity);
        $this->scopeFramePool = new ObjectPool(BorrowedScopeFrame::class, $scopeFramePoolCapacity);
        $this->tokenPool = new SplStack();
        $this->tokenPoolCapacity = $tokenPoolCapacity;
    }

    public function registerScope(
        string $scopeId,
        ?string $parentScopeId,
        string $fqcn,
        int $coroutineId,
    ): void {
        $this->ledger->registerScope($scopeId, $parentScopeId, $fqcn, $coroutineId);
    }

    public function disposeScope(string $scopeId): void
    {
        $this->ledger->disposeScope($scopeId);
    }

    public function nextScopeId(): string
    {
        return $this->ledger->nextScopeId();
    }

    /** @param array<class-string, object> $inheritedScopedInstances */
    public function acquireScopeFrame(array $inheritedScopedInstances = []): BorrowedScopeFrame
    {
        return $this->scopeFramePool->acquire(BorrowedScopeFrame::poolInitializer($inheritedScopedInstances));
    }

    public function releaseScopeFrame(BorrowedScopeFrame $frame): void
    {
        $this->scopeFramePool->release($frame);
    }

    /**
     * Open a new TaskRun. Creates the run record, derives the child's
     * cancellation token from the parent's, opens a trace span, returns
     * the handle. The caller is responsible for invoking the task body
     * and calling join() on success or fail()/cancel() on error.
     *
     * Wiring (subsequent slice): the framework's primitives call this
     * before invoking the task body. The TaskMiddleware chain runs
     * around the body; on body return, complete() + reap() finalize.
     *
     * @param Scopeable|Executable $task    The dispatchable task.
     * @param Scope                $parent  Parent scope; cancellation source and attribute carrier.
     * @param DispatchMode         $mode    How the task is being dispatched.
     * @param string|null          $name    Optional explicit name (e.g. from Traceable). Falls
     *                                      back to class FQCN, then a generated id.
     */
    public function start(
        Scopeable|Executable|\Closure $task,
        Scope $parent,
        DispatchMode $mode,
        ?string $name = null,
        ?string $parentRunId = null,
        ?CancellationToken $token = null,
    ): TaskRun {
        $id = $this->ledger->nextRunId();
        $resolvedName = $name ?? self::resolveName($task, $id);
        $metadata = self::resolveMetadata($task);
        $scopeId = $parent instanceof ScopeIdentity ? $parent->scopeId : null;

        $supervisorOwnsToken = $token === null;
        if ($token === null) {
            $parentToken = $parent instanceof Cancellable
                ? $parent->cancellation()
                : CancellationToken::none();
            $token = $this->acquireCompositeToken($parentToken);
        }

        $run = $this->taskRunPool->acquire(
            TaskRun::poolInitializer($id, $resolvedName, $parentRunId, $mode, $token, $scopeId, $metadata),
        );
        $run->tokenOwnedBySupervisor = $supervisorOwnsToken;

        $this->ledger->register($run);

        return $run;
    }

    /**
     * Mark the run as actively executing. Called immediately before the
     * task body runs.
     */
    public function markRunning(TaskRun $run): void
    {
        $this->ledger->markRunning($run->id);
    }

    /**
     * Record that the run is currently parked on a wait point. Called by
     * the framework's suspend wrappers (Suspendable::call(), delay(),
     * worker submit, singleflight, lock acquire, etc.).
     *
     * Returns a closure that clears the wait reason when the suspend
     * completes — designed to be invoked in a finally block:
     *
     *   $clear = $supervisor->beginWait($run, WaitReason::http('GET', $url));
     *   try { return $client->execute($url); }
     *   finally { $clear(); }
     */
    public function beginWait(TaskRun $run, WaitReason $reason): \Closure
    {
        $this->assertCanWait($run, $reason);

        $this->ledger->beginWait($run->id, $reason);

        $ledger = $this->ledger;
        $runId = $run->id;
        return static function () use ($ledger, $runId): void {
            $ledger->clearWait($runId);
        };
    }

    /**
     * Mark the run completed with a return value. Reap is the caller's
     * responsibility once any post-complete cleanup is done.
     */
    public function complete(TaskRun $run, mixed $value): void
    {
        $run->state = RunState::Completed;
        $run->value = $value;
        $run->endedAt = microtime(true);
        $this->ledger->complete($run->id, $value);
    }

    /**
     * Mark the run failed with a throwable.
     */
    public function fail(TaskRun $run, Throwable $error): void
    {
        $run->state = RunState::Failed;
        $run->error = $error;
        $run->endedAt = microtime(true);
        $run->failureTree = $this->tree();
        $this->ledger->fail($run->id, $error);
    }

    /**
     * Cancel the run. Cancels the run's cancellation token (which
     * cascades to engine handles via registered listeners) and marks
     * the ledger state. Idempotent.
     */
    public function cancel(TaskRun $run): void
    {
        $run->state = RunState::Cancelled;
        $run->endedAt ??= microtime(true);
        $run->cancellation->cancel();
        $this->ledger->cancel($run->id);
    }

    /**
     * Final cleanup for a terminal run. Releases any still-held leases
     * (a violation — they should have been released by their owner —
     * but we don't leak), removes the run from the ledger.
     */
    public function reap(TaskRun $run): void
    {
        if (!$run->isTerminal()) {
            // Defensive: caller should not reap a running run. Treat as
            // an implicit cancel rather than silently leaving it dangling.
            $this->cancel($run);
        }

        if ($run->leases !== []) {
            foreach ($run->leases as $orphaned) {
                $this->trace->log(
                    TraceType::Defer,
                    DiagnosticCode::LeaseOrphan->value,
                    [
                        'run' => $run->id,
                        'task' => $run->name,
                        'domain' => $orphaned->domain,
                        'key' => $orphaned->key,
                        'mode' => $orphaned->mode,
                        'detail' => 'lease still held at reap; release missing in owner code',
                    ],
                );
            }
        }

        $token = $run->tokenOwnedBySupervisor ? $run->cancellation : null;

        try {
            $this->ledger->reap($run->id);
        } finally {
            $run->error = null;
            $run->value = null;
            $run->failureTree = null;
            $run->leases = [];
            $run->currentWait = null;
            $this->taskRunPool->release($run);

            if ($token !== null) {
                $this->releaseToken($token);
            }
        }
    }

    public function poolStats(): SupervisorPoolStats
    {
        return new SupervisorPoolStats(
            taskRun: $this->taskRunPool->stats(),
            scopeFrame: $this->scopeFramePool->stats(),
            token: new TokenPoolStats(
                hits: $this->tokenPoolHits,
                misses: $this->tokenPoolMisses,
                free: $this->tokenPool->count(),
                capacity: $this->tokenPoolCapacity,
            ),
        );
    }

    /**
     * Register a lease against an active run. Pool / transaction / lock
     * acquisitions call this; the supervisor checks the run's existing
     * leases for violations before recording.
     *
     * @throws LeaseViolation DiagnosticCode::PoolNestedAcquire, DiagnosticCode::LockOrderViolation
     */
    public function registerLease(TaskRun $run, Lease $lease): void
    {
        $existing = $this->ledger->find($run->id);
        if ($existing === null) {
            return;
        }

        if ($lease instanceof PoolLease) {
            foreach ($existing->leases as $held) {
                if ($held instanceof PoolLease && $held->domain === $lease->domain) {
                    throw new LeaseViolation(
                        diagnostic: DiagnosticCode::PoolNestedAcquire,
                        detail: "nested acquire from pool '{$lease->domain}' (already holds connection #{$held->key})",
                        runId: $run->id,
                        runName: $run->name,
                        offending: $lease,
                    );
                }
            }
        }

        if ($lease instanceof LockLease) {
            foreach ($existing->leases as $held) {
                if (!$held instanceof LockLease) {
                    continue;
                }
                if ($held->domain !== $lease->domain) {
                    continue;
                }
                // @dev-cleanup-ignore — re-entry on same key is allowed; lock manager handles upgrades
                if ($held->key === $lease->key) {
                    continue;
                }
                if (strcmp($lease->key, $held->key) < 0) {
                    throw new LeaseViolation(
                        diagnostic: DiagnosticCode::LockOrderViolation,
                        detail: "out-of-order lock acquire in domain '{$lease->domain}': "
                              . "would acquire '{$lease->key}' while holding '{$held->key}' "
                              . "— canonical-sort multi-key acquires to prevent deadlock",
                        runId: $run->id,
                        runName: $run->name,
                        offending: $lease,
                    );
                }
            }
        }

        $this->ledger->addLease($run->id, $lease);
    }

    /**
     * Worker dispatch crosses a process boundary. Any lease that points at
     * process-local state must be released before the task leaves the parent.
     *
     * @throws LeaseViolation DiagnosticCode::PoolCrossBoundary
     */
    public function assertCanEnterWorker(TaskRun $run): void
    {
        $existing = $this->ledger->find($run->id);
        if ($existing === null) {
            return;
        }

        foreach ($existing->leases as $held) {
            if (!$held instanceof PoolLease && !$held instanceof TransactionLease) {
                continue;
            }

            throw new LeaseViolation(
                diagnostic: DiagnosticCode::PoolCrossBoundary,
                detail: "process-local lease '{$held->domain}'/'{$held->key}' held across worker dispatch boundary",
                runId: $run->id,
                runName: $run->name,
                offending: $held,
            );
        }
    }

    /**
     * Transactions may wait on local coordination primitives, but must not
     * perform unrelated external IO while the transaction lease is held.
     *
     * @throws LeaseViolation DiagnosticCode::TransactionExternalIo
     */
    public function assertCanWait(TaskRun $run, WaitReason $reason): void
    {
        if (!self::isExternalWait($reason)) {
            return;
        }

        $existing = $this->ledger->find($run->id);
        if ($existing === null) {
            return;
        }

        foreach ($existing->leases as $held) {
            if (!$held instanceof TransactionLease) {
                continue;
            }

            throw new LeaseViolation(
                diagnostic: DiagnosticCode::TransactionExternalIo,
                detail: "external {$reason->kind->value} wait attempted while transaction "
                    . "'{$held->domain}'/'{$held->key}' is open",
                runId: $run->id,
                runName: $run->name,
                offending: $held,
            );
        }
    }

    /**
     * Release a lease previously registered against the run. Called by
     * the lease's owner (pool client, lock manager, transaction handle)
     * when the underlying resource is returned.
     */
    public function releaseLease(TaskRun $run, Lease $lease): void
    {
        $this->ledger->releaseLease($run->id, $lease);
    }

    /**
     * Bracketed lease helper: register, run body, release in finally.
     * Pool clients should prefer this form so leases can never leak past
     * a thrown body. Returns whatever the body returns.
     *
     * @template T
     * @param \Closure(): T $body
     * @return T
     */
    public function withLease(TaskRun $run, Lease $lease, \Closure $body): mixed
    {
        $this->registerLease($run, $lease);
        try {
            return $body();
        } finally {
            $this->releaseLease($run, $lease);
        }
    }

    /**
     * Detached snapshot of the live task tree. Powers diagnostic surfaces.
     *
     * @return list<TaskRunSnapshot>
     */
    public function tree(?string $rootRunId = null): array
    {
        return $this->ledger->tree($rootRunId);
    }

    public function liveCount(): int
    {
        return $this->ledger->liveCount();
    }

    public function liveScopeCount(): int
    {
        return $this->ledger->liveScopeCount();
    }

    private static function isExternalWait(WaitReason $reason): bool
    {
        return match ($reason->kind) {
            WaitKind::Http,
            WaitKind::Redis,
            WaitKind::Surreal,
            WaitKind::Worker,
            WaitKind::Process,
            WaitKind::StreamWrite,
            WaitKind::WsFrameWrite,
            WaitKind::WsFrameRead,
            WaitKind::UdpReceive,
            WaitKind::Custom => true,
            WaitKind::Delay,
            WaitKind::Postgres,
            WaitKind::Singleflight,
            WaitKind::Lock,
            WaitKind::Channel,
            WaitKind::Input => false,
        };
    }

    private static function resolveName(Scopeable|Executable|\Closure $task, string $fallbackId): string
    {
        if ($task instanceof \Closure) {
            try {
                $reflection = new \ReflectionFunction($task);
                $file = $reflection->getFileName();
                if ($file !== false) {
                    return basename($file) . ':' . $reflection->getStartLine();
                }
            } catch (\Throwable) {
            }
            return $fallbackId;
        }

        $class = $task::class;

        if (str_contains($class, '@anonymous')) {
            if (property_exists($task, 'traceName')) {
                $hint = $task->traceName ?? null;
                if (is_string($hint) && $hint !== '') {
                    return $hint;
                }
            }
            return $fallbackId;
        }

        return $class;
    }

    /**
     * @return array{fqcn: string, sourcePath: string, sourceLine: int}
     */
    private static function resolveMetadata(Scopeable|Executable|\Closure $task): array
    {
        if ($task instanceof \Closure) {
            try {
                $reflection = new ReflectionFunction($task);
                $file = $reflection->getFileName();

                return [
                    'fqcn' => \Closure::class,
                    'sourcePath' => $file === false ? '' : $file,
                    'sourceLine' => (int) $reflection->getStartLine(),
                ];
            } catch (Throwable) {
                return ['fqcn' => \Closure::class, 'sourcePath' => '', 'sourceLine' => 0];
            }
        }

        if ($task instanceof Task) {
            return [
                'fqcn' => Task::class,
                'sourcePath' => $task->sourceLocation,
                'sourceLine' => 0,
            ];
        }

        return ['fqcn' => $task::class, 'sourcePath' => '', 'sourceLine' => 0];
    }

    private function acquireCompositeToken(CancellationToken $parent): CancellationToken
    {
        if ($this->tokenPool->isEmpty()) {
            $this->tokenPoolMisses++;
            return CancellationToken::composite($parent);
        }

        $this->tokenPoolHits++;
        $token = $this->tokenPool->pop();
        $token->resetForPool();
        $token->wireComposite($parent);

        return $token;
    }

    private function releaseToken(CancellationToken $token): void
    {
        if ($token->immutableNone) {
            return;
        }

        $token->release();

        if ($this->tokenPool->count() >= $this->tokenPoolCapacity) {
            return;
        }

        $this->tokenPool->push($token);
    }
}
