<?php

declare(strict_types=1);

namespace Phalanx\Dory\Command;

use Phalanx\Archon\Command\Arg;
use Phalanx\Archon\Command\CommandConfig;
use Phalanx\Archon\Command\CommandContext;
use Phalanx\Archon\Command\DescribesCommand;
use Phalanx\Archon\Command\Opt;
use Phalanx\Dory\DoryBuilder;
use Phalanx\Task\Scopeable;

final class RunCommand implements Scopeable, DescribesCommand
{
    public function __invoke(CommandContext $ctx): int
    {
        $scriptPath = (string) $ctx->args->required('script');
        $resolved = realpath($scriptPath);

        if ($resolved === false || !file_exists($resolved)) {
            fwrite(STDERR, "Script not found: {$scriptPath}\n");
            return 1;
        }

        if ($ctx->options->flag('verbose')) {
            putenv('DORY_VERBOSE=1');
        }

        $timeout = $ctx->options->get('timeout');
        if ($timeout !== null) {
            putenv("DORY_SCRIPT_TIMEOUT={$timeout}");
        }

        $builder = new DoryBuilder();
        $builder->script($resolved);

        return $builder->run();
    }

    public static function commandConfig(): CommandConfig
    {
        return new CommandConfig(
            description: 'Run a Dory script',
            arguments: [
                Arg::required('script', 'Path to the PHP script'),
            ],
            options: [
                Opt::flag('verbose', 'v', 'Show detailed output'),
                Opt::value('timeout', 't', 'Script timeout in seconds', '30'),
            ],
            examples: [
                'dory run deploy.php',
                'dory run sync.php --timeout=120',
                'dory r migrate.php -v',
            ],
            aliases: ['r'],
        );
    }
}
