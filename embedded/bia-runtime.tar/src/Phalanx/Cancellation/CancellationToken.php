<?php

declare(strict_types=1);

namespace Phalanx\Cancellation;

use Swoole\Timer;

/**
 * Cooperative cancellation signal.
 *
 * Factories:
 * - none()       — never cancelled (cancel() is a no-op)
 * - create()     — manually cancellable
 * - timeout(s)   — auto-cancels after s seconds via engine timer; timer is
 *                  cleared on early cancel() so a deferred callback never races
 * - composite(...$tokens) — cancels when ANY source cancels; pre-cancels if any
 *                           source is already cancelled at construction
 *
 * cancel() is idempotent. Listeners fire in registration order. The internal
 * timer ID slot supports the timeout() factory; cancel() always clears it.
 */
class CancellationToken
{
    private(set) bool $isCancelled = false;

    /** @var array<int, \Closure(): void> */
    private array $listeners = [];

    private int $listenerSeq = 0;

    private ?int $timerId = null;

    /** @var list<array{self, int}> */
    private array $unregisters = [];

    private(set) bool $immutableNone = false;

    private function __construct()
    {
    }

    /** @internal Pool reset — clears all state for reuse via ObjectPool */
    public function resetForPool(): void
    {
        $this->release();
        $this->isCancelled = false;
        $this->listenerSeq = 0;
        $this->immutableNone = false;
    }

    public static function none(): self
    {
        $t = new self();
        $t->immutableNone = true;

        return $t;
    }

    public static function create(): self
    {
        return new self();
    }

    public static function timeout(float $seconds): self
    {
        $token = new self();
        $ms = max(1, (int) round($seconds * 1000));
        $timerId = Timer::after($ms, static function () use ($token): void {
            $token->cancel();
        });
        $token->timerId = is_int($timerId) ? $timerId : null;

        return $token;
    }

    /**
     * Composite token. Cancels when any source cancels. Pre-cancels if any source
     * is already cancelled. Listeners registered on source tokens are unregistered
     * when the composite cancels, preventing proportional listener accumulation
     * across concurrent timeout usage.
     */
    public static function composite(self ...$sources): self
    {
        $composite = new self();
        foreach ($sources as $source) {
            if ($source->isCancelled) {
                $composite->cancel();

                return $composite;
            }
            $key = $source->onCancel(static function () use ($composite): void {
                $composite->cancel();
            });
            $composite->unregisters[] = [$source, $key];
        }

        return $composite;
    }

    /** @internal Wire composite cancellation sources on a pool-reset token */
    public function wireComposite(self ...$sources): void
    {
        $token = $this;
        foreach ($sources as $source) {
            if ($source->isCancelled) {
                $this->cancel();

                return;
            }
            $key = $source->onCancel(static function () use ($token): void {
                $token->cancel();
            });
            $this->unregisters[] = [$source, $key];
        }
    }

    public function throwIfCancelled(): void
    {
        if ($this->isCancelled) {
            throw new Cancelled();
        }
    }

    public function cancel(): void
    {
        if ($this->isCancelled || $this->immutableNone) {
            return;
        }
        $this->isCancelled = true;

        if ($this->timerId !== null) {
            Timer::clear($this->timerId);
            $this->timerId = null;
        }

        foreach ($this->unregisters as [$source, $key]) {
            $source->offCancel($key);
        }
        $this->unregisters = [];

        $listeners = $this->listeners;
        $this->listeners = [];
        foreach ($listeners as $listener) {
            try {
                $listener();
            } catch (\Throwable) {
            }
        }
    }

    public function release(): void
    {
        if ($this->timerId !== null) {
            Timer::clear($this->timerId);
            $this->timerId = null;
        }
        foreach ($this->unregisters as [$source, $key]) {
            $source->offCancel($key);
        }
        $this->unregisters = [];
        $this->listeners = [];
    }

    /** @param \Closure(): void $listener */
    public function onCancel(\Closure $listener): int
    {
        if ($this->isCancelled) {
            try {
                $listener();
            } catch (\Throwable) {
            }

            return -1;
        }

        $key = $this->listenerSeq++;
        $this->listeners[$key] = $listener;

        return $key;
    }

    public function offCancel(int $key): void
    {
        if ($key < 0) {
            return;
        }
        unset($this->listeners[$key]);
    }
}
