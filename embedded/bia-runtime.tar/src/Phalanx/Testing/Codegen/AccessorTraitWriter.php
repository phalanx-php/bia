<?php

declare(strict_types=1);

namespace Phalanx\Testing\Codegen;

use RuntimeException;

final class AccessorTraitWriter
{
    public const string TARGET_TRAIT = 'TestAppAccessors';
    public const string TARGET_NAMESPACE = 'Phalanx\\Testing\\Generated';

    /** @param list<LensMetadata> $lenses */
    public function render(array $lenses): string
    {
        $useBlock = self::collectUseStatements($lenses);
        $accessorBlock = self::renderAccessors($lenses);
        $namespace = self::TARGET_NAMESPACE;
        $trait = self::TARGET_TRAIT;

        $uses = $useBlock !== '' ? "\n{$useBlock}" : '';
        $body = $accessorBlock !== '' ? $accessorBlock : '';

        return <<<PHP
            <?php

            declare(strict_types=1);

            namespace {$namespace};
            {$uses}
            /**
             * @generated
             *
             * Generator:   AccessorTraitWriter
             * Package:     phalanx-runtime
             * Regenerate:  composer dump-autoload
             *
             * This file is auto-generated. Do not edit — changes are
             * overwritten on the next generation pass.
             */
            trait {$trait}
            {
            {$body}}

            PHP;
    }

    /** @param list<LensMetadata> $lenses */
    public function write(array $lenses, string $targetFile): void
    {
        $directory = dirname($targetFile);

        if (!is_dir($directory) && !@mkdir($directory, 0o775, true) && !is_dir($directory)) {
            throw new RuntimeException("Unable to create directory {$directory} for generated accessors.");
        }

        $contents = $this->render($lenses);

        if (file_put_contents($targetFile, $contents) === false) {
            throw new RuntimeException("Unable to write generated accessors to {$targetFile}.");
        }
    }

    /**
     * @param list<LensMetadata> $lenses
     * @return array<string,string> fqcn => alias
     */
    private static function buildAliasMap(array $lenses): array
    {
        $fqcns = array_unique(array_column($lenses, 'lensClass'));

        $shortNameCount = [];
        foreach ($fqcns as $fqcn) {
            $short = self::shortName($fqcn);
            $shortNameCount[$short] = ($shortNameCount[$short] ?? 0) + 1;
        }

        $aliasMap = [];
        $usedAliases = [];

        foreach ($fqcns as $fqcn) {
            $short = self::shortName($fqcn);

            if ($shortNameCount[$short] === 1 && !isset($usedAliases[$short])) {
                $aliasMap[$fqcn] = $short;
                $usedAliases[$short] = true;
                continue;
            }

            $parts = explode('\\', $fqcn);
            $alias = implode('', array_slice($parts, -2));
            $base = $alias;
            $i = 2;
            while (isset($usedAliases[$alias])) {
                $alias = $base . $i++;
            }

            $aliasMap[$fqcn] = $alias;
            $usedAliases[$alias] = true;
        }

        return $aliasMap;
    }

    /** @param list<LensMetadata> $lenses */
    private static function collectUseStatements(array $lenses): string
    {
        $aliasMap = self::buildAliasMap($lenses);

        $lines = [];
        foreach ($aliasMap as $fqcn => $alias) {
            $short = self::shortName($fqcn);
            $lines[] = $alias === $short
                ? 'use ' . $fqcn . ';'
                : 'use ' . $fqcn . ' as ' . $alias . ';';
        }

        sort($lines);

        if ($lines === []) {
            return '';
        }

        return implode("\n", $lines) . "\n";
    }

    /** @param list<LensMetadata> $lenses */
    private static function renderAccessors(array $lenses): string
    {
        $aliasMap = self::buildAliasMap($lenses);

        $sorted = $lenses;
        usort($sorted, static fn(LensMetadata $a, LensMetadata $b): int => $a->accessor <=> $b->accessor);

        $blocks = [];

        foreach ($sorted as $lens) {
            $alias = $aliasMap[$lens->lensClass] ?? self::shortName($lens->lensClass);
            $blocks[] = "    public {$alias} \${$lens->accessor} {\n"
                . "        get => \$this->lens({$alias}::class);\n"
                . "    }\n";
        }

        return implode("\n", $blocks);
    }

    private static function shortName(string $fqcn): string
    {
        $position = strrpos($fqcn, '\\');

        return $position === false ? $fqcn : substr($fqcn, $position + 1);
    }
}
