<?php

declare(strict_types=1);

namespace Phalanx\AiProviders\HomeDir;

use Phalanx\AiProviders\Series;

/**
 * Typed Series leaf over {@see Locator}. Vendor HomeDir adapters may
 * subclass to add tool-specific predicates (e.g., `byCwd(string $cwd): static`);
 * subclasses must add only methods, not constructor state, per Series contract.
 *
 * @extends Series<Locator>
 */
class Locators extends Series
{
}
