<?php

declare(strict_types=1);

namespace Phalanx\AiProviders\Conversation\Record;

use Phalanx\AiProviders\Conversation\Record;
use Phalanx\AiProviders\Conversation\RecordType;

/**
 * A permission decision recorded during the agent's execution. The
 * `mode` describes whether the tool or action was allowed outright,
 * required user confirmation, or was denied. `scope` narrows which
 * tool or path pattern the decision applied to.
 */
final class PermissionMode extends Record
{
    final public RecordType $type { get => RecordType::PermissionMode; }

    private(set) ?string $scope = null;

    public function __construct(
        string $id,
        ?int $sequence,
        \DateTimeImmutable $at,
        private(set) PermissionMode\Mode $mode,
        ?string $permissionScope = null,
    ) {
        $this->scope = $permissionScope;
        parent::__construct($id, $sequence, $at);
    }

    /**
     * @return array<string, mixed>
     */
    final protected function payload(): array
    {
        return [
            'mode' => $this->mode->value,
            'scope' => $this->scope,
        ];
    }
}
