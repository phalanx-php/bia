<?php

declare(strict_types=1);

namespace Phalanx\Err;

interface Err
{
    public Severity $severity { get; }
}
