<?php

declare(strict_types=1);

namespace Phalanx\Runtime\Tests\Resilience;

use Phalanx\Application;
use Phalanx\Boot\AppContext;
use Phalanx\Cancellation\Cancelled;
use Phalanx\Mark\Mark;
use Phalanx\Scope\ExecutionScope;
use Phalanx\Service\ServiceBundle;
use Phalanx\Service\Services;
use Phalanx\Supervisor\InProcessLedger;
use Phalanx\Task\Task;
use Phalanx\Testing\PhalanxTestCase;

/**
 * Cross-checks the isolation invariant: a child's cancellation token is
 * derived from the parent's, but siblings do NOT share a token. Cancelling
 * sibling A must not propagate to sibling B.
 *
 * Cancelling the parent must propagate to ALL children.
 */
final class SiblingCancelIsolationStressTest extends PhalanxTestCase
{
    public function testParentCancelTerminatesAllSiblingsQuickly(): void
    {
        $this->scope->run(static function (ExecutionScope $_scope): void {
            $ledger = new InProcessLedger();
            $app = self::buildApp($ledger);
            $appScope = $app->createScope();
            $token = $appScope->cancellation();

            // Schedule cancellation after siblings are running.
            \Swoole\Coroutine::create(static function () use ($token): void {
                \Swoole\Coroutine::sleep(0.02);
                $token->cancel();
            });

            $tasks = [];
            $siblingCount = 50;
            for ($i = 0; $i < $siblingCount; $i++) {
                $tasks["sib-{$i}"] = Task::of(static function (ExecutionScope $s): void {
                    $s->delay(Mark::s(5));
                });
            }

            $start = microtime(true);
            $caught = null;
            try {
                $appScope->concurrent(...$tasks);
            } catch (Cancelled $e) {
                $caught = $e;
            }
            $elapsed = microtime(true) - $start;

            self::assertNotNull($caught, 'parent cancel should propagate to children and surface');
            self::assertLessThan(1.0, $elapsed, sprintf('took %.3fs', $elapsed));

            $appScope->dispose();
            self::assertSame(0, $ledger->liveCount());
        });
    }

    public function testCompletedSiblingDoesNotCancelOthers(): void
    {
        $this->scope->run(static function (ExecutionScope $_scope): void {
            $ledger = new InProcessLedger();
            $app = self::buildApp($ledger);
            $appScope = $app->createScope();

            // One sibling completes fast, the others a bit slower. All must
            // complete; the fast one must not signal cancellation to peers.
            $tasks = [
                'fast' => Task::of(static fn(ExecutionScope $s): int => 1),
                'slow-a' => Task::of(static function (ExecutionScope $s): int {
                    $s->delay(Mark::ms(50));
                    return 2;
                }),
                'slow-b' => Task::of(static function (ExecutionScope $s): int {
                    $s->delay(Mark::ms(50));
                    return 3;
                }),
                'slow-c' => Task::of(static function (ExecutionScope $s): int {
                    $s->delay(Mark::ms(50));
                    return 4;
                }),
            ];

            $results = $appScope->concurrent(...$tasks);

            self::assertSame(['fast' => 1, 'slow-a' => 2, 'slow-b' => 3, 'slow-c' => 4], $results);

            $appScope->dispose();
            self::assertSame(0, $ledger->liveCount());
        });
    }

    public function testRaceCancelsLosersOnly(): void
    {
        $this->scope->run(static function (ExecutionScope $_scope): void {
            $ledger = new InProcessLedger();
            $app = self::buildApp($ledger);
            $appScope = $app->createScope();

            $start = microtime(true);
            $value = $appScope->race(...[
                Task::of(static fn(ExecutionScope $s): int => 1),  // wins
                Task::of(static function (ExecutionScope $s): never {
                    $s->delay(Mark::s(5));
                    throw new \RuntimeException('should be cancelled');
                }),
                Task::of(static function (ExecutionScope $s): never {
                    $s->delay(Mark::s(5));
                    throw new \RuntimeException('should be cancelled');
                }),
            ]);
            $elapsed = microtime(true) - $start;

            self::assertSame(1, $value);
            self::assertLessThan(1.0, $elapsed, 'losers cancelled fast');

            $appScope->dispose();
            self::assertSame(0, $ledger->liveCount());
        });
    }

    private static function buildApp(InProcessLedger $ledger): Application
    {
        $bundle = new class extends ServiceBundle {
            public function services(Services $services, AppContext $context): void
            {
            }
        };
        return Application::starting()
            ->providers($bundle)
            ->withLedger($ledger)
            ->compile();
    }
}
