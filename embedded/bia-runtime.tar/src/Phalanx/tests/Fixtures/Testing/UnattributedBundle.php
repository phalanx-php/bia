<?php

declare(strict_types=1);

namespace Phalanx\Runtime\Tests\Fixtures\Testing;

use Phalanx\Boot\AppContext;
use Phalanx\Service\ServiceBundle;
use Phalanx\Service\Services;
use Phalanx\Testing\TestLens;

final class UnattributedBundle extends ServiceBundle
{
    public function services(Services $services, AppContext $context): void
    {
    }

    #[\Override]
    public static function lens(): TestLens
    {
        return TestLens::of(UnattributedLens::class);
    }
}
