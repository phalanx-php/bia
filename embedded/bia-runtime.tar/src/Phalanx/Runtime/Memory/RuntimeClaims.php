<?php

declare(strict_types=1);

namespace Phalanx\Runtime\Memory;

use Swoole\Lock;

final class RuntimeClaims
{
    private Lock $lock;

    public function __construct(private readonly ManagedSwooleTables $tables)
    {
        $this->lock = new Lock(Lock::MUTEX);
    }

    public function claim(string $key, float $ttl, string $token = ''): bool
    {
        $now = microtime(true);
        $rowKey = self::key($key);

        // Swoole 6 has no non-blocking trylock(); a near-zero timeout gives the claim path a bounded fail-fast lock.
        if (!$this->lock->lock(timeout: 0.001)) {
            return false;
        }

        try {
            $row = $this->tables->claims->get($rowKey);
            if (is_array($row) && (float) $row['expires_at'] > $now) {
                return false;
            }

            $this->tables->claims->set($rowKey, [
                'token' => self::fit($token === '' ? $rowKey : $token, 64),
                'claimed_at' => $now,
                'expires_at' => $now + $ttl,
            ]);
            $this->tables->mark('claims');

            return true;
        } finally {
            $this->lock->unlock();
        }
    }

    public function release(string $key): void
    {
        $this->tables->claims->del(self::key($key));
    }

    public function sweepExpired(float $now): int
    {
        $count = 0;
        foreach ($this->tables->claims as $key => $row) {
            if (!is_array($row) || (float) $row['expires_at'] > $now) {
                continue;
            }

            $this->tables->claims->del((string) $key);
            $count++;
        }

        return $count;
    }

    public function destroy(): void
    {
        // Swoole 6 Lock auto-frees on __destruct; no explicit destroy() exists.
        unset($this->lock);
    }

    private static function key(string $key): string
    {
        return substr(sha1($key), 0, 32);
    }

    private static function fit(string $value, int $length): string
    {
        return mb_strlen($value) <= $length ? $value : mb_substr($value, 0, $length);
    }
}
