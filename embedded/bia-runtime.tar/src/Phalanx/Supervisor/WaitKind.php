<?php

declare(strict_types=1);

namespace Phalanx\Supervisor;

/**
 * Kind axis of a WaitReason. Standard kinds are recorded by framework
 * suspend points so the live task tree can answer "what is this task
 * waiting on?" without speculation. Application code uses Custom with
 * a descriptive detail.
 */
enum WaitKind: string
{
    case Delay = 'delay';
    case Http = 'http';
    case Postgres = 'postgres';
    case Redis = 'redis';
    case SurrealDb = 'surrealdb';
    case Worker = 'worker';
    case Singleflight = 'singleflight';
    case Lock = 'lock';
    case Channel = 'channel';
    case Process = 'process';
    case Input = 'input';
    case StreamWrite = 'stream.write';
    case WsFrameWrite = 'ws.frame.write';
    case WsFrameRead = 'ws.frame.read';
    case UdpReceive = 'udp.receive';
    case Custom = 'custom';
}
