<?php

declare(strict_types=1);

namespace Phalanx\Console\Tests\Fixtures\Commands;

use Phalanx\Scope\Scope;
use Phalanx\Task\Scopeable;

/**
 * Test fixture: sets a static flag when invoked. Used to assert the
 * dispatcher correctly traversed into a nested CommandGroup.
 */
final class NestedRanCommand implements Scopeable
{
    public static bool $ran = false;

    public function __invoke(Scope $scope): int
    {
        self::$ran = true;
        return 0;
    }
}
